#!/bin/bash
python3 /home/infinitylabs/Pictures/WikiDemocopy/IndexerVer7/txtToJSON/Docs/txtToJSON.py
DIR='/home/infinitylabs/Pictures/WikiDemocopy/IndexerVer7/txtToJSON/'
i=1
for file in ls "$DIR"*.json
do
    mongoimport  --db vor -c testfilesearch --file $i.json 
    echo $i
    i=$((i+1))
done
echo  "Done exporting Documents to MongoDB"
mongoexport  --db vor -c testfilesearch  -o /home/infinitylabs/Pictures/WikiDemocopy/IndexerVer7/txtToJSON/filesearch.json
echo "Imported filesearch.json"

python3 ImportData.py
echo "ID.txt generated"
mongoimport  --db vor -c TFIDFtest  --file TFIDF.json
echo "exported TFIDF.json to MongoDb"
echo "starting server"
python pymongotest.py
firefox index.html