/**
 * Particleground demo
 * @author Jonathan Nicol - @mrjnicol
 */

$(document).ready(function() {
  $('#particles').jParticle({
    dotColor: '#5cbdaa',
    lineColor: '#5cbdaa',
	 particlesNumber: 210,
	 createLinkDist: 150,
	 disableMouse: true,
	 linkDist: 50,
	 background: 'linear-gradient(to right, rgba(179,220,237,1) 0%, rgba(41,184,229,1) 50%, rgba(188,224,238,1) 100%)'
  });
  $('.intro').css({
    'margin-top': -($('.intro').height() / 2)
  });
});