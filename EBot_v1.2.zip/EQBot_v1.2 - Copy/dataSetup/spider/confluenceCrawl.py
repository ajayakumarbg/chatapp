
import requests, json
def printResponse(r):
    print ('{} {}\n'.format(json.dumps(r.json(), sort_keys=True, indent=4, separators=(',', ': ')), r))



r = requests.get('https://confluence.equifax.com/confluence/rest/api/content',
    params={'title' : 'Page title to comment on'},
    auth=('axk396', 'April@2018'),
                 proxies={"https": "http://proxy-user.wip.us.equifax.com/proxy.js",
                          "http": "http://proxy-user.wip.us.equifax.com/proxy.js"})

printResponse(r)
parentPage = r.json()['results'][0]
"""
pageData = {'type':'comment', 'container':parentPage,
    'body':{'storage':{'value':"<p>A new comment</p>",'representation':'storage'}}}
r = requests.post('http://localhost:8080/confluence/rest/api/content',
    data=json.dumps(pageData),
    auth=('admin','admin'),
    headers=({'Content-Type':'application/json'}))
    """
printResponse(r)