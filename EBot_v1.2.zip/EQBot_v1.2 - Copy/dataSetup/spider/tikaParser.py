import tika
from tika import parser
import os
import requests
import glob
from os import path

os.environ['NO_PROXY'] = 'localhost'
session = requests.Session()
session.trust_env = False
#tika.TikaClientOnly = True
tika.tika.TIKA_SERVER_ENDPOINT ='http://127.0.0.1:9998'
tika.tika.TIKA_PATH ='C:\\installs\\pylibs\\tika\\server'
tika.tika.TIKA_LOG_PATH = 'C:\\installs\\pylibs\\tika\\logs'
#parsed = parser.from_file('C:\\Documents\\forBot\\1.CMS Fusion Introduction.docx')
#parsed = parser.from_file('C:\\Documents\\forBot\\j2m-shareable.jpg')
#print(parsed["content"])
#print(parsed["metadata"])



basepath = path.dirname(__file__)
genPath = path.abspath(path.join(basepath,  '../txtToJSON/gen/'))
print(genPath)

path ='C:\\Documents\\forBot\\docx\\*.docx'
#genPath = 'txtToJSON\\gen\\'

files = glob.glob(genPath+'\\*txt')
for f in files:
    os.remove(f)

file_list =[]
rootdir = 'C:\\Documents\\forBot\\docx\\'

for subdir, dirs, files in os.walk(rootdir):
    for file in files:
        #print (os.path.join(subdir, file))
        file_list.append((os.path.join(subdir, file)))


ext = [".doc", ".docx", ".pdf", ".ppt", ".pptx", ".xls", ".xlsx"]

files = glob.glob(path)
i=0
for name in file_list:
    print ( name )
    try:
        if( name.endswith(tuple(ext))):
            parsed = parser.from_file(name)
            #print(parsed["metadata"])
            #print(parsed["content"])
            fh = open(genPath+'\\'+str(i+1)+'.txt',"w",encoding='utf8')
            fh.write(parsed["content"])
            fh.close()
            i+=1
    except:
        print("exception for : "+name)


