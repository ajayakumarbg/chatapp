# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 09:22:50 2018

@author: C63165
"""

import json
import glob
import os
from os import path
import re
"""
Converting txt files to json files for importing to mongoDB
"""

def isLineEmpty(line):
    return len(line.strip()) < 5

def isValidSentence(line):
    return len(line.strip().split()) < 10

ddict={}
basepath = path.dirname(__file__)
genPath = path.abspath(path.join(basepath,  '../txtToJSON/'))
#genPath = 'C:\\Users\\axk396\\MyExperiments\\Chat bot Apps\\Crawl-index-master_2\\Crawl-index-master\\App2\\txtToJSON\\'
files = glob.glob(genPath+'/genJson\\*json')
for f in files:
    os.remove(f)

files = glob.glob(genPath+'/gen\\*.txt')
i=0
for f in files:
    ddict['content']={}
    file=open('txtToJSON/gen/'+str(i+1)+'.txt','r',encoding='utf8')
    lines = file.readlines()
    file.close()
    filestr = []


    for line in lines:
        #line = re.sub('\t+', '', line)
        if not isLineEmpty(line):
            if not isValidSentence(line):
                filestr.append(line.replace('\t', ' ').replace('\n', '').replace('\u00b7','').replace('\u2019', '\'').replace('\u2013', '-').replace('\u201c','"').replace('\u201d','"').replace('\u2018',"'").replace('\u2019',"'"))
    #filestr=file.read().split('\n')


    ddict['content']['contents']=filestr

    file=open('txtToJSON/genJson/'+str(i+1)+'.json','w',encoding='utf8')
    file.write(json.dumps(ddict))
    file.close()
    i += 1

