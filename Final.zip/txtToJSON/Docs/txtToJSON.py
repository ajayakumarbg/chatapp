# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 09:22:50 2018

@author: C63165
"""

import json
"""
Converting txt files to json files for importing to mongoDB
"""
ddict={}

import glob
import errno
path ='./Docs/*.txt'
files = glob.glob(path)
i=0
for name in files:
   try:
    ddict['content']={}
    file=open(name,'r',encoding='utf8')
    filestr=file.read().split('\n')
    file.close()
    
    ddict['content']['contents']=filestr
    
    file=open(str(i+1)+'.json','w',encoding='utf8')
    file.write(json.dumps(ddict))
    file.close()
    i+=1
   except IOError as exc:
        if exc.errno != errno.EISDIR:
            raise
