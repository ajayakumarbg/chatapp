import base64
from pymongo import MongoClient




client = MongoClient('localhost:27017')
db= client.vor

#app.config['MONGO_DBNAME'] = 'testfilesearch'
#app.config['MONGO_URI'] = 'mongodb://127.0.0.1:27017/vor'
#mongo = PyMongo(app)
 
with open("asia.jpg", "rb") as imageFile:
    str = base64.b64encode(imageFile.read())
    print (str)


db.imagecollection.insert_one(
        {
        "name": "asia",
        "doc":"5acc43293ccc4603943529ad",
        "image":str
        })







fh = open("imageToSave.jpg", "wb")
fh.write(str.decode('base64'))
fh.close()