var username=prompt('Enter username')
var socket = io.connect('http://127.0.0.1:5000');
socket.emit('username', username)

if(socket !== undefined){
  console.log('Connected to socket...');
}
var $messages = $('.messages-content'),
    d, h, m,
    i = 0;

$(window).load(function() {
  
  $messages.mCustomScrollbar();

  setTimeout(function() {

    fakeMessage();
  }, 100);
  welcome(username,welcome_text);
});





  socket.on('imageConversionByServer', function(data) {
    
    var $img = $("<img/>");
    $img.attr("src", "dribbble-01_1x.jpg");
    $("#img2").append($img);
    $('<div class="message new"><figure class="avatar"><img src="dribbble-01_1x.jpg" /></figure>'+ '<div  style="width:155px; height:130px;">'+'<img src="imageToSave.jpg"; />'+'</div>' +'</div>').appendTo($('.mCSB_container')).addClass('new');
    console.log($('<img id="img2">'))
  });






function updateScrollbar() {
  $messages.mCustomScrollbar("update").mCustomScrollbar('scrollTo', 'bottom', {
    scrollInertia: 10,
    timeout: 0
  });
}

function setDate(){
  d = new Date()
  if (m != d.getMinutes()) {
    m = d.getMinutes();
    $('<div class="timestamp">' + d.getHours() + ':' + m + '</div>').appendTo($('.message:last'));
  }
}

function insertMessage() {
  msg = $('.message-input').val();
  var flag=0
  socket.emit('input', msg,flag,username)
  if ($.trim(msg) == '') {
    return false;
  }
  $('<div class="message message-personal">' + msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
  setDate();
  $('.message-input').val(null);
  updateScrollbar();
  setTimeout(function() {
    fakeMessage();
  }, 1000 + (Math.random() * 20) * 100);
}

$('.message-submit').click(function() {
  insertMessage();
});

$(window).on('keydown', function(e) {
  if (e.which == 13) {
    insertMessage();
    return false;
  }
});
$.fn.thumbs = function () {
  self=this,
  $(self)
    .find('.sprite-fa-thumbs-up-grey')


 
};
var out_l;

class more{

};
class more2{
  
};
var txt=" [More]";

  

class next{
  
};
class relPara{

};


  
  // $(self)
  // .append($('<div>').addClass('sprite sprite-fa-thumbs-up-grey'),
  // $('<div>').addClass('sprite sprite-fa-thumbs-down-grey'));

 
$(".sprite-fa-thumbs-down-grey").click(function(){
      
  rel_para[rel_loc]=-1;
  socket.emit('relevance',rel_para);
   });
$(".sprite-fa-thumbs-up-grey").click(function(){
      
  rel_para[rel_loc]=1;
  socket.emit('relevance',rel_para);
  });




var nxt=" [Next doc match]";
var flag2=0
var rel_para=[0,0,0]
var rel_loc=0
var welcome_text="Hello, how can I help you,"

function welcome(username,welcome_text){
  console.log('in welcome',username)

  $('<div class="message new"><figure class="avatar"><img src="dribbble-01_1x.jpg" /></figure>'+ "Hello "+ username +", how can I help you?" +'</div>').appendTo($('.mCSB_container')).addClass('new');
}

function fakeMessage() {
  if ($('.message-input').val() != '') {
    return false;
  }
  $('<div class="message loading new"><figure class="avatar"><img src="dribbble-01_1x.jpg" /></figure><span></span></div>').appendTo($('.mCSB_container'));
  updateScrollbar();

  output1=null
  setTimeout(function() {
  output1=null
    
    socket.on('output',function(output1,id){
    var doc_id=id
    
    updateScrollbar();
    console.log('output1 received from doc id ',id)
    flag=0
    out_l=output1.length
    Fake=JSON.stringify(output1[0].replace(/(\r\n|\n|\r)/gm," "));
    // console.log(out_l)
    console.log(Fake)

    
    // Fake4=JSON.stringify(output1[3].replace(/(\r\n|\n|\r)/gm," "));
    if (out_l>2) {
      Fake2=JSON.stringify(output1[1].replace(/(\r\n|\n|\r)/gm," "));
      Fake3=JSON.stringify(output1[2].replace(/(\r\n|\n|\r)/gm," "));
      
      
      
    }
    // console.log(txt2)
    flag2=0
    console.log('socket before end and flag2:',flag2)
    });

    console.log('socket function end and flag2:',flag2)

    if (flag2==0){
    setTimeout(() => {
     console.log('in timeout') 
     console.log('fake in timeout:',Fake)
    $('.message.loading').remove();
    console.log('before if')
    if(out_l>1){
      console.log('in if')

      $('<div class="message new"><figure class="avatar"><img src="dribbble-01_1x.jpg" /></figure>'+ Fake + '<more>'+ txt + '</more>' +'</div>').appendTo($('.mCSB_container')).addClass('new');
      rel_loc=0;
      $("more").click(function(){
        updateScrollbar();
        rel_loc=1;
      $('<div class="message new"><figure class="avatar"><img src="dribbble-01_1x.jpg" /></figure>'+ Fake2 + '<more2>'+ txt + '</more2>' +'</div>').appendTo($('.mCSB_container')).addClass('new'); 
      updateScrollbar();
      $("more2").click(function(){
        $('<div class="message new"><figure class="avatar"><img src="dribbble-01_1x.jpg" /></figure>'+ Fake3 + '<next>'+ nxt + '</next>' + '</div>').appendTo($('.mCSB_container')).addClass('new'); 
        rel_loc=2;
        updateScrollbar();
        $("next").on('click',function(click){
          console.log('button click')
          flag=1;
          socket.emit('input', msg,flag,username )
          console.log('socket emit log, flag:',flag,' and flag2:',flag2)
          fakeMessage();
          
          });
      });
    });
      
    }
    else {
    $('<div class="message new"><figure class="avatar"><img src="dribbble-01_1x.jpg" /></figure>'+ Fake + '<next>' + nxt + '</next>' + '</div>').appendTo($('.mCSB_container')).addClass('new');
    console.log('in else')
    updateScrollbar();
    $("next").on('click',function(click){
    console.log('button click')
    flag=1;
    socket.emit('input', msg,flag,username )
    console.log('socket emit log, flag:',flag,' and flag2:',flag2)
    fakeMessage();
    });
    }
    flag2=1 
  },1000)
}
 
    $('.message.loading').remove();

    setDate();
    updateScrollbar();
  }, 1000 + (Math.random() * 20) * 100);

  
}
