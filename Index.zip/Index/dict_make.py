import json
import re
import pprint
import pickle
import unicodedata

fe=open('dictionary.json')
f=fe.read()
fe.close()
data=json.loads(f)
result=[]
for key in data:
    key =unicodedata.normalize('NFKD', key).encode('ascii','ignore')
    # print(type(key))
    result.append(key)

# print(result)
sf=open('dictionary.txt','wb')
pickle.dump(result, sf)
sf.close()
