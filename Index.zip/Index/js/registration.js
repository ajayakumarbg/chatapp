var $ = require('jquery');
const mongo = require('mongodb').MongoClient;
// var url = "mongodb://amith:amith123@ds239368.mlab.com:39368/vor";
var username = $('#name').val();
var EmployeeID=$('#e-id').val();
var password = $('#password').val();
var designation = $('#user_job').val();
var interests = $('.light').val();
mongo.connect('mongodb://amith:amith123@ds239368.mlab.com:39368/vor', function(err, db){
    if(err){
        throw err;
    }
    console.log('MongoDB connected...');
    var dbo=db.collection('user_profile')
    // var username = $('#name').val();
    // var EmployeeID=$('#e-id').val();
    // var password = $('#password').val();
    // var designation = $('#user_job').val();
    // var interests = $('.light').val();
    $('#register').click(function() {
        
            var myobj = { name: username, employeeID: EmployeeID, key: password, role: designation, tags: interests };
            dbo.insertOne(myobj, function(err, res) {
            if (err) throw err;
            console.log("user added");
            dbo.close();
            });
        });  
    
        });  
