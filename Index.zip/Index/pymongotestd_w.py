

from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
from flask_socketio import SocketIO
import unicodedata
import bson
import json
import string
import spellcheck_c
import nltk, re, pprint
from nltk import word_tokenize, pos_tag
from nltk.corpus import wordnet as wn
from nltk.stem import PorterStemmer
ps = PorterStemmer()


username=None
iter_n=0

def symmetric_sentence_similarity(sentence1, sentence2):
    
    return (sentence_similarity(sentence1, sentence2) + sentence_similarity(sentence2, sentence1)) 
def penn_to_wn(tag):
    
    if tag.startswith('N'):
        return 'n'
 
    if tag.startswith('V'):
        return 'v'
 
    if tag.startswith('J'):
        return 'a'
 
    if tag.startswith('R'):
        return 'r'
 
    return None
 
def tagged_to_synset(word, tag):
    wn_tag = penn_to_wn(tag)
    if wn_tag is None:
        return None
 
    try:
        return wn.synsets(word, wn_tag)[0]
    except:
        return None
 
def sentence_similarity(sentence1, sentence2):
    
   
    sentence1 = pos_tag(word_tokenize(sentence1))
    sentence2 = pos_tag(word_tokenize(sentence2))
 
   
    synsets1 = [tagged_to_synset(*tagged_word) for tagged_word in sentence1]
    synsets2 = [tagged_to_synset(*tagged_word) for tagged_word in sentence2]
 
    
    synsets1 = [ss for ss in synsets1 if ss]
    synsets2 = [ss for ss in synsets2 if ss]
 
    score, count = 0.0, 0
    
    
    for synset in synsets1:
        high= [synset.path_similarity(ss) for ss in synsets2]
        best_score=0
        if len(high) !=0 :
            best_score = max(high)
 
        
        if best_score is not None:
            score += best_score
            count += 2
 
    
    if count > 0 :
        score /= count
    return score
 


app = Flask(__name__)

socketio = SocketIO(app)

app.config['MONGO_DBNAME'] = 'testfilesearch'
app.config['MONGO_URI'] = 'mongodb://amith:amith123@ds239368.mlab.com:39368/vor'

mongo = PyMongo(app)

def get_nested(data, *args):
      if args and data:
        element  = args[0]
        if element:
            
            value = data.get(element)
            
             
        return value if len(args) == 1  else get_nested(value, *args[1:]) 


def addUser(username,user_db):
    print('at add user')
    userToAdd={
        "name":username,
        "query_list": [],
        "category": []

    }
    user_db.insert_one(userToAdd)
    print('user added:',userToAdd)
    
    return usersearch(username)
rel_para=[0,0,0]

#@socketio.on('relevance')
#def printer(rel_para):
   
   # print('relevance received')
    #print(rel_para)

        
@socketio.on('username')

def usersearch(username):
    print('username received')
    user_db=mongo.db.user_db
    user_data=user_db.find_one({"name": username})    
    if user_data==None:
        addUser(username,user_db)
    else:
        print(user_data)
    return user_data
        
      

@socketio.on('input')
def get_all_frameworks(name,iter_n,username):
    print('iter number is',iter_n)
    
    r=''
    for i in '!@#$%^&*()_+-={}[]|\\\';:"<,>.?/':
           r=name.split(i)
           name=' '.join(r)
    # global name1
    name=name.lower()
    name2=name.split()
    print(name)
    print(type(name))
    n=[]
    f=open('stopwords.txt','r')
    stopword=f.read().split()
    for word in name2:
        word=word.encode('ascii','strict')
        
        if word not in stopword:
         n.append(word)

    name2=n
    
    
    print (name2)
    mongo.db.user_db.update({"name":username},{"$addToSet":{"query_list":{ "$each": name2}}})
    doc = []
    output = []
    bestmatch=[]
    
    framework = mongo.db.TFIDFtest

    output1 = []
    f=open('ID.txt','r')
    
    doc=eval(f.read())
    f.close()
    match={}
    x=0
    y=0
    m=0
    l=0
    s=0
    n=3
    q=framework.find_one()
    crawl = mongo.db.testfilesearch
    name3=[]
    name3=name2
    output1=[]
    name2=spellcheck_c.min_edit_distance(name3)
    print(name2)
    out="Sorry, did you mean "
    if name2==1:
        name2=name3
    else:
        for i in range(len(name2)):
            out+= name2[i] + ' '
            print(name,type(name))
            # name=unicode(name)
            name = name.replace(name3[i],name2[i])
            print(name2[i])
            print(name3[i])
            # a2=name3[i]          
            # a1=unicodedata.normalize('NFKD', a1).encode('ascii','ignore')
            # c=unicodedata.normalize('NFKD', name).encode('ascii','ignore')
            # a2=unicodedata.normalize('NFKD', a2).encode('ascii','ignore')
            # c.replace(a2,a1)
            # name=c
            # name.replace(name3[i],name2[i])
            print('replaced '+name)
            # print('name2 type', type(name2[i]))
            print('name type', type(name),name)
        out+= '?'
        output1.append(out)  
        output1.append(3)      
        socketio.emit('output',output1)
    print(name2)
    # for q_word in name3:
    #     r_word=spellcheck_c.min_edit_distance(q_word)
    #     if r_word !=1:
    #         out +=  r_word +' ?'
    #         name2.append(unicode(r_word))
     

    # if r_word.count(r_word[0]) == len(r_word):
    #     name2=name3
    # x=0
    while x < len(doc):
            
        s=0
        y=0
        flag=True
        # print('query is: ',name2)
        while y < len(name2):
                
            # print('in second while', name2)
            t=[get_nested(q,ps.stem(w),doc[x]) for w in getSyn(name2[y])]
            t=[b for b in t if b != None]
                
            if sum(t)==0:
                t=[get_nested(q,ps.stem(name2[y]),doc[x])]
            if None not in t:
                t=sum(t)
            else:
                flag=False
                break
            if flag and t==0:
                flag=False
                break
            s=s+t
            y+=1
        if flag:
            match[s]=x
            print('x is:',x)
        x+=1
    best=sorted(match)
    best.reverse()
    # print('array best',best)
    best=[b for b in best[0:n] if b>0]
    bestmatch=[match[b] for b in best]
    print('bestmatch is :',bestmatch)
    print('array best is:',best)
    c = crawl.find_one({'_id' : bson.ObjectId(doc[bestmatch[iter_n]])})     



    img=mongo.db.imagecollection

    imgd = img.find_one({'doc':doc[bestmatch[iter_n]]})
    if imgd!=None:
        img64=imgd['image']
        socketio.emit('imageConversionByServer', "data:image/png;base64,"+ img64);
    #if img64!=None:
        print(img64)
        fh = open("imageToSave.jpg", "wb")
        fh.write(img64.decode('base64'))
        fh.close()
        #socketio.emit('imageConversionByServer',img64)
        
    if c:
            output = {'output' : c['content']}
    else:
            output = "No such name"
        
   
    b=0
    score=0
    best1=0
    para=0
    best3=0
    para3=0
    para2=0
    best2=0
    content_length=len(output['output']['contents'])
    while b <  content_length:
            mylist = json.dumps(output['output']['contents'][b])
            if len(mylist) > 10:
                # print('in mylist if', name)
                score=symmetric_sentence_similarity(name, mylist)
                if score > best1 :
                    print('in if')
                    print('score is:',score)
                    best3=best2
                    best2=best1
                    best1=score
                    para3=para2
                    para2=para
                    para=b
                    print('para2 at b=',b,' is :',para2)
                    print('para3 at b=',b,' is :',para3)
            b+=1

    
    
    print('para is:',para)
    print('para2 is:', para2)
    print('para3 is:',para3)
    
    output1=[]
    output1.append(output['output']['contents'][para])
    if para!=0:

        output1.append(output['output']['contents'][para2])
        output1.append(output['output']['contents'][para3])
        
    print('output1 is:',output1) 
        
    user=mongo.db.userdata
    val=user.find_one({"name":username,"query":name.lower()})
    @socketio.on('relevance')
    def printer(rel_para):
        print (rel_para)
        user=mongo.db.userdata
        val=user.find_one({"name":username,"query":name.lower()})
    
        if val==None :
            emp_rec1 = {
            "name":username,
            "docchoice":doc[bestmatch[iter_n]],
            "query":name.lower(),
            "parachoice":rel_para
            }
            user.insert_one(emp_rec1)


        user.update_many(
            {"name":username, "query":name.lower()},
            {
                "$set":{
                        "docchoice":doc[bestmatch[iter_n]],
                        "parachoice":rel_para
                        },
                "$currentDate":{"lastModified":True}
                 
                }
        )         
    
    #if val==None :
        #emp_rec1 = {
        #"name":username,
        #"docchoice":doc[bestmatch[iter_n]],
       # "query":name.lower(),
       # "parachoice":rel_para
        #}
        #user.insert_one(emp_rec1)


    #user.update_many(
        #{"name":username, "query":name.lower()},
        #{
                #"$set":{
                        #"docchoice":doc[bestmatch[iter_n]],
                        #"parachoice":rel_para
                       # },
               # "$currentDate":{"lastModified":True}
                 
               # }
        #)
    #socketio.emit('imageConversionByServer',img64)         
    socketio.emit('output',output1)
    #socketio.emit('imageConversionByServer',img64)
    return jsonify({'search result' : output})
    #socketio.emit('imageConversionByServer',img64)
        
      

def getSyn(word):
    syns= []
    for synset in wn.synsets(word):
        syns=syns+synset.lemma_names()
    syns=set([w.lower() for w in syns])
    return syns




if __name__ == '__main__':
    socketio.run(app)
