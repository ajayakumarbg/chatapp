const express = require('express');
const bodyParser= require('body-parser')
const MongoClient = require('mongodb').MongoClient
const app = express();
1
app.use(bodyParser.urlencoded({extended: true}))

var db

MongoClient.connect('mongodb://amith:amith123@ds239368.mlab.com:39368/vor', (err, client) => {
  if (err) return console.log(err)
  db=client.db('db')
  if (err){throw err;}
  
  app.listen(3000, () => {
    console.log('listening on 3000')
  })
})
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/registration.html')
    res.sendFile(__dirname + '/css/main.css')
    // Note: __dirname is directory that contains the JavaScript source code. Try logging it and see what you get!
    // Mine was '/Users/zellwk/Projects/demo-repos/crud-express-mongo' for this app.
  })
app.post('/registration', (req, res) => {
    db.collection('user_profile').save(req.body, (err, result) => {
      if (err) return console.log(err)
  
      console.log('saved to database')
      res.redirect('/')
    })
  })

// app.get('/', (req, res) => {
//   res.sendFile(__dirname + '/registration.html')
// })