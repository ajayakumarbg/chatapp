

from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
from flask_socketio import SocketIO
import bson
import json
import string
import base64
import nltk, re, pprint
from nltk import word_tokenize, pos_tag
from nltk.corpus import wordnet as wn
from nltk.stem import PorterStemmer
ps = PorterStemmer()




def symmetric_sentence_similarity(sentence1, sentence2):
    
    return (sentence_similarity(sentence1, sentence2) + sentence_similarity(sentence2, sentence1)) 
def penn_to_wn(tag):
    
    if tag.startswith('N'):
        return 'n'
 
    if tag.startswith('V'):
        return 'v'
 
    if tag.startswith('J'):
        return 'a'
 
    if tag.startswith('R'):
        return 'r'
 
    return None
 
def tagged_to_synset(word, tag):
    wn_tag = penn_to_wn(tag)
    if wn_tag is None:
        return None
 
    try:
        return wn.synsets(word, wn_tag)[0]
    except:
        return None
 
def sentence_similarity(sentence1, sentence2):
    """ compute the sentence similarity using Wordnet """
   
    sentence1 = pos_tag(word_tokenize(sentence1))
    sentence2 = pos_tag(word_tokenize(sentence2))
 
   
    synsets1 = [tagged_to_synset(*tagged_word) for tagged_word in sentence1]
    synsets2 = [tagged_to_synset(*tagged_word) for tagged_word in sentence2]
 
    
    synsets1 = [ss for ss in synsets1 if ss]
    synsets2 = [ss for ss in synsets2 if ss]
 
    score, count = 0.0, 0
    #best_score=0
    
    for synset in synsets1:
        high= [synset.path_similarity(ss) for ss in synsets2]
        best_score=0
        if len(high) !=0 :
            best_score = max(high)
 
        
        if best_score is not None:
            score += best_score
            count += 2
 
    
    if count > 0 :
        score /= count
    return score
 


app = Flask(__name__)

socketio = SocketIO(app)

app.config['MONGO_DBNAME'] = 'testfilesearch'
app.config['MONGO_URI'] = 'mongodb://amith:amith123@ds239368.mlab.com:39368/vor'

mongo = PyMongo(app)

def get_nested(data, *args):
      if args and data:
        element  = args[0]
        if element:
            
            value = data.get(element)
            
             
        return value if len(args) == 1  else get_nested(value, *args[1:]) 
def addUser(username,user_db):
    print('at add user')
    userToAdd={
        "name":username,
        "query_list": [],
        "category": []

    }
    user_db.insert_one(userToAdd)
    print('user added:',userToAdd)
    
    return usersearch(username)


@socketio.on('relevance')
def printer(rel_para):
    print('relevance received')
    print(rel_para)
        
@socketio.on('username')

def usersearch(username):
    print('username received')
    user_db=mongo.db.user_db
    user_data=user_db.find_one({"name": username})    
    if user_data==None:
        addUser(username,user_db)
    else:
        print(user_data)
    return user_data

@socketio.on('input')
def get_all_frameworks(name,iter_n,username):
    print('iter number is',iter_n)
    # print('input is:',data)
    # name=data[0]
    # iter_n=data[1]
    r=''
    for i in '!@#$%^&*()_+-={}[]|\\\';:"<,>.?/':
           r=name.split(i)
           name=' '.join(r)
    name=name.lower()
    name2=name.split()
    n=[]
    f=open('stopwords.txt','r')
    stopword=f.read().split()
    for word in name2:
      if word not in stopword:
         n.append(word)
    name2=n
    
    stemmed=[ps.stem(w) for w in name2]
    print (name2)
    if name2[0]=="equifax":
        img=mongo.db.images.find_one({"title": name2[0]})
        print('img searching')
        data=img["data"]
        socketio.emit('imageConversionByServer', "data:image/png;base64,"+ data);


    mongo.db.user_db.update({"name":username},{"$addToSet":{"query_list":name2}})
    print('data updated')
    doc = []
    output = []
    bestmatch=[]
    
    framework = mongo.db.TFIDFtest
    user_data=mongo.db.user_db.find_one({"name":username})
    print(user_data)
    output1 = []
    f=open('ID.txt','r')
    
    doc=eval(f.read())
    match={}
    x=0
    y=0
    m=0
    l=0
    s=0
    n=3
    #try:
    for q in framework.find():
            output1.append({'files' : q[stemmed[y]]})
    while x < len(doc):
            
            s=0
            y=0
            flag=True
            while y < len(name2):
                ti=[ps.stem(w) for w in getSyn(name2[y]) ]
                # print('ti is:',ti)
                
                #print(q)
                t=[get_nested(q,ps.stem(w),doc[x]) for w in getSyn(name2[y])]
                t=[b for b in t if b != None]
                # print('t is:',t)
                if sum(t)==0:
                    t=[get_nested(q,ps.stem(name2[y]),doc[x])]
                if None not in t:
                    t=sum(t)
                else:
                    flag=False
                    break
                if flag and t==0:
                    flag=False
                    break
                s=s+t
                y+=1
            if flag:
                match[s]=x
            x+=1
    best=sorted(match)
    best.reverse()
    best=[b for b in best[0:n] if b>0]
    #print(best)
    bestmatch=[match[b] for b in best]
    print('bestmatch is :',bestmatch)
    print('array best is:',best)

                
                
    #best=sorted(match)
    #best.reverse()
   # best=[k for k in best[0:3] if k>0]
    #bestmatch=[match[k] for k in best] 
    #print(bestmatch) 
        
                 
                #if get_nested(q,name2[y],doc[x])==None:
                    #flag=False
                    #break
                #s= s + get_nested(q,name2[y],doc[x])
                
                
            #if s > l and flag:
                
                #l=s
                #m=x    
           
    #except:
        #print('An error occurred.')
        #output1= {"output": {"contents": ['Oops! I am sorry, I am confused']}}
        #socketio.emit('output',output1) 
    #return;	
        
    #print(doc[m]) 
    
    crawl = mongo.db.testfilesearch
    # print(bestmatch[iter_n])
    if len(bestmatch)==1:
        iter_n=0
        print('in if, iter value:',iter_n)

    c = crawl.find_one({'_id' : bson.ObjectId(doc[bestmatch[iter_n]])})
        
    if c:
            output = {'output' : c['content']}
    else:
            output = "No such name"
        
    #print(output1['output']['contents'])
    b=0
    score=0
    best1=0
    para=0
    best3=0
    para3=0
    para2=0
    best2=0
    content_length=len(output['output']['contents'])
    while b <  content_length:
            mylist = json.dumps(output['output']['contents'][b])
            if len(mylist) > 10:
                score=symmetric_sentence_similarity(name, mylist)
                if score > best1 :
                    # print('in if')
                    print('score is:',score)
                    best3=best2
                    best2=best1
                    best1=score
                    para3=para2
                    para2=para
                    para=b
                    print('para2 at b=',b,' is :',para2)
                    print('para3 at b=',b,' is :',para3)
            b+=1

    
    
    print('para is:',para)
    print('para2 is:', para2)
    print('para3 is:',para3)
    # output2=output1['output']['contents'][para]
    # output1= {"output": {"contents": [output2]}}  
    output1=[]
    output1.append(output['output']['contents'][para])
    if para!=0:

        output1.append(output['output']['contents'][para2])
        output1.append(output['output']['contents'][para3])
        
    print('output1 is:',output1) 
        # print('output2 is:',output2)      
    socketio.emit('output',output1)
    return jsonify({'search result' : output})
        
      

def getSyn(word):
    syns= []
    for synset in wn.synsets(word):
        syns=syns+synset.lemma_names()
    syns=set([w.lower() for w in syns])
    return syns




if __name__ == '__main__':
    socketio.run(app)
