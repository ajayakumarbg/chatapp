# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 13:20:26 2018

@author: C63165
"""

from Indexer import Documents
from Indexer import Document
import time
#import pylab



#numfiles=[]
#times=[]
#for end in range(2,21):
#    print('Trial: '+str(end-1))
#    numfiles.append(end-1)
t0=time.time()
docs=Documents()
print('Initiallizing import...')
for i in range(1,21):
       print('Importing Document No: '+str(i)+'...')
       doc=Document(str(i)+'.txt')
       docs.addDoc(doc)
print('Importing Done!')
docs.update()
docs.exportToCSV()
docs.exportToJSON()
docs.getDocJSON()
t1=time.time()
print('Time taken: '+str(t1-t0))
#times.append(t1-t0)

#pylab.plot(numfiles,times)

           
           
