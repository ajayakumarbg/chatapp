# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 19:19:33 2018

@author: kuttus
"""
import math
import json
class Document(object):
    fileID=1
    def __init__(self,name):
        self.name=name
        self.file=open(name,'r')
        self.stringraw=self.file.read()
        r=''
        string=self.stringraw
        for i in '!@#$%^&*()_+-={}[]|\\\';:"<,>.?/':
           r=string.split(i)
           string=' '.join(r)
        string=string.lower()
        self.string=string
        self.wordlist=self.string.split()
        self.fileid='d'+str(Document.fileID)
        Document.fileID+=1
        self.file.close()
        
    def getName(self):
        return self.name
    
    def getWordCount(self):
        return len(self.wordlist)
    
    def getWordList(self):
        return self.wordlist
    
    def getCountOf(self,word):
        return self.wordlist.count(word)
    
    def isWordIn(self,word):
        return word in self.wordlist
    
    def getTF(self,word):
        return float(self.getCountOf(word))/float(self.getWordCount())
    
    def getID(self):
        return self.fileid
    
    def __eq__(self,doc):
        return self.fileid==doc.fileid
    
    
class Documents(object):
    def __init__(self):
        self.docs=[]
        self.wordlist=[]
        self.IDF={}
        self.TFIDF={}
        self.word_doc={}
        stopfile=open('stop_words.txt','r')
        self.stopwords=stopfile.read()
        self.stopwords=self.stopwords.split()
    
    def getNumDocs(self):
        return len(self.docs)
    
    def getIDF(self,word):
        n=0
        for doc in self.docs:
            if doc.isWordIn(word):
                n=n+1
        return math.log(self.getNumDocs()/n)
    
    def updateIDF(self):
        for word in self.wordlist:
            self.IDF[word]=self.getIDF(word)
    
    def computeTFIDF(self):
        for word in self.wordlist:
            for doc in self.docs:
                if word in doc.wordlist:
                     self.TFIDF[doc.getID()][word]=doc.getTF(word)*self.IDF[word]
                else:
                    self.TFIDF[doc.getID()][word]=0
    
    def matchword_doc(self):
        for word in self.wordlist:
            best=0
            bestmatch=None
            for ID in self.TFIDF:
                if self.TFIDF[ID][word]>best:
                    best=self.TFIDF[ID][word]
                    bestmatch=ID
            self.word_doc[word]=bestmatch
            
    def addDoc(self,doc):
        if doc not in self.docs:
            self.docs.append(doc)
            for word in doc.getWordList():
                if  word not in self.wordlist:
                    if len(word)>1 and word not in self.stopwords:
                      self.wordlist.append(word)

    def getMatch(self, word):
        try:
         return self.word_doc[word]
        except:
            return None
    
    def update(self):
        print('Initializing Indexing...')
        for doc in self.docs:
          self.TFIDF[doc.getID()]={}
        print('Initializing Done!')
        print('Computing IDF...')
        self.updateIDF()
        print('Computing IDF done!')
        print('Computing TFIDF...')
        self.computeTFIDF()
        print('Computing TFIDF Done!')
        self.matchword_doc()
        print('Finished Updating!')
    
    def exportToCSV(self):
        print('Exporting to TFIDF.csv...')
        file=open('TFIDF.csv','w')
        file.write('File ID,')
        for word in self.wordlist:
            file.write(word+',')
        file.write('\n')
        for doc in self.docs:
            file.write(str(doc.getID())+',')
            for word in self.wordlist:
                file.write(str(self.TFIDF[doc.getID()][word])+',')
            file.write('\n')
        file.close()
        print('Exporting Done!')
    
    def exportToJSON(self):
        print('Exporting to TFIDF.json...')
        jsonstr=json.dumps(self.TFIDF)
        file=open('TFIDF.json','w')
        file.write(jsonstr)
        file.close
        print('Exporting Done!')
        
    def getDocJSON(self):
        docJSON={}
        for doc in self.docs:
            docJSON[str(doc.getID())]=doc.stringraw
        
        file=open('docs.json','w')
        file.write(json.dumps(docJSON))
        file.close()



