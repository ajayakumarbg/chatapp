
from flask_cors import CORS
from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
# from flask_socketio import SocketIO
import bson
import spacy
import json
import string
import nltk, re, pprint
from nltk import word_tokenize, pos_tag
from nltk.corpus import wordnet as wn
from nltk.stem import PorterStemmer
ps = PorterStemmer()

from nltk.stem import WordNetLemmatizer
from Clusterer import Cluster,tokenize_and_stem
from Doc2vec_search import getCentroids,loadModel
import pickle
import spellcheck_c
from gensim.summarization.summarizer import summarize
lm=WordNetLemmatizer()
nlp = spacy.load('en_core_web_md')

username=None
iter_n=0
doc=[]
bestmatch=[]

tfidf,strlist,vocab_frame=loadModel('tfidfmodel.sav','strlist.sav','vocab_frame.sav')
file=open('doclist.sav','rb')
doclist=pickle.load(file)
file.close()
file=open('ddict.sav','rb')
ddict=pickle.load(file)
file.close()
file=open('doc2vec_model.sav','rb')
model=pickle.load(file)
file.close()
file=open('cdict.sav','rb')
cdict=pickle.load(file)
file.close()
clusters=list(range(len(doclist)))
for c in cdict:
    for d in cdict[c]:
        clusters[d]=c
        
#clusters,cdict=getClusterDict(km)
#            
#centroids=getCentroids(cdict,tfidf[1],len(cdict))
#
#describeCluster(strlist,clusters,centroids,vocab_frame,tfidf[2],len(cdict))
cluster=Cluster(doclist,cdict,ddict,tfidf[0],tfidf[1])

 


app = Flask(__name__, static_url_path='')
CORS(app)

app.config['MONGO_DBNAME'] = 'testfilesearch'
app.config['MONGO_URI'] = 'mongodb://127.0.0.1:27017/vor'



mongo = PyMongo(app)

def get_nested(data, *args):
      if args and data:
        element  = args[0]
        if element:
            
            value = data.get(element)
            
             
        return value if len(args) == 1  else get_nested(value, *args[1:]) 


def addUser(username,user_db):
    print('at add user')
    userToAdd={
        "name":username,
        "query_list": [],
        "category": []

    }
    user_db.insert_one(userToAdd)
    print('user added:',userToAdd)
    
    return True
rel_para=[0,0,0]
#@socketio.on('relevance')
#def printer(rel_para):
   
   # print('relevance received')
    #print(rel_para)

@app.route("/")
def index():
    return app.send_static_file('index.html')

    # return app.send_static_file('index.html')  
@app.route('/relevance', methods=['POST'])
def printer():
    print('id is',doc_id)
    data=request.get_json(force= True)
    print(data)
    import ast
    data = ast.literal_eval(data)
    print(type(data))
    # print('here is data',rel_para,username,msg)
    print ('here is data',data)
    print(type(data))
    user=mongo.db.userdata
    val=user.find_one({"name":data['username'],"query":data['name'].lower()})

    if val==None :
        emp_rec1 = {
        "name":data['username'],
        "docchoice":doc_id,
        "query":data['name'].lower(),
        "parachoice":data['rel_para']
        }
        user.insert_one(emp_rec1)


    user.update_many(
        {"name":data['username'], "query":data['name'].lower()},
        {
            "$set":{
                    "docchoice":doc_id,
                    "parachoice":data['rel_para']
                    },
            "$currentDate":{"lastModified":True}
                
            }
    )  
    print (user)
    return jsonify({"success": True})
# @socketio.on('username')


# def usersearch(username):
#     print('username received')
#     user_db=mongo.db.user_db
#     user_data=user_db.find_one({"name": username})    
#     if user_data==None:
#         addUser(username,user_db)
#     else:
#         print(user_data)
#     return user_data
        
      

@app.route('/input/<query>')
def get_all_frameworks(query):
    iter_n=int(query[-1])
    name=query[:-1]    
    checker = spellcheck_c.min_edit_distance(name)
    print('spellcheck out', checker)
    if checker != 1:
        out="Sorry, did you mean "
        out+= checker
        out+= ' ?'
        output1=[]
        output1.append(out)  
        output1.append(3)      
        # socketio.emit('correction',output1)
        name = checker
        
    IDs=cluster.clustSearch(name,'e')
    print(IDs)
    paras=cluster.getParaList(IDs[iter_n])
    global doc_id
    doc_id= IDs[iter_n]
    print(iter_n)
    #print(paras)
    b=0
    score=0
    best1=0
    para=0
    best3=0
    para3=0
    para2=0
    best2=0
    content_length=len(paras)
    #print(symmetric_sentence_similarity(name, paras[5]))
    while b <  content_length:
            mylist = paras[b]
            token1=nlp(mylist)
            token2=nlp(name)
            if len(mylist) > 10:
                score=(token1.similarity(token2))
                if score > best1 :
                    print('in if')
                    print('score is:',score)
                    best3=best2
                    best2=best1
                    best1=score
                    para3=para2
                    para2=para
                    para=b
                    print('para2 at b=',b,' is :',para2)
                    print('para3 at b=',b,' is :',para3)
            b+=1

    
    
    print('para is:',para)
    print('para2 is:', para2)
    print('para3 is:',para3)
    
    output1=[]
    output1.append(paras[para])
    if para!=0:

        output1.append(paras[para2])
        output1.append(paras[para3])
        
    print('output1 is:',output1[0])      
    output=[]
    my_lst_str = ''.join(map(str, output1))
    print(summarize(my_lst_str))
    
    # socketio.emit('output',output1)
    #socketio.emit('imageConversionByServer',img64)
    return jsonify(output1)


      

def getSyn(word):
    syns= []
    for synset in wn.synsets(word):
        syns=syns+synset.lemma_names()
    syns=set([w.lower() for w in syns])
    return syns




if __name__ == '__main__':
    app.run(port=5000, debug=True)
