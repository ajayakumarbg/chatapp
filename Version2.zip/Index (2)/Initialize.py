# -*- coding: utf-8 -*-
"""
Created on Fri May 25 12:46:04 2018

@author: C63165
"""

from Indexer import processJSON
from Clusterer import importData,vectorize,buildVocabFrame
from Doc2vec_Clusterer import labelSent,d2v
from Doc2vec_search import getClusters
import pickle

files=['testfilesearch.json']
ddict=processJSON('processed.json',files)


file=open('ddict.sav','wb')
pickle.dump(ddict,file)
file.close()

data=importData('processed.json')
doclist=data[0]
strlist=data[1]

file=open('doclist.sav','wb')
pickle.dump(doclist,file)
file.close()

file=open('strlist.sav','wb')
pickle.dump(strlist,file)
file.close()

tagged_content=labelSent(strlist)

file=open('tagged.sav','wb')
pickle.dump(tagged_content,file)
file.close()

model=d2v(tagged_content)

file=open('doc2vec_model.sav','wb')
pickle.dump(model,file)
file.close()

tfidfmodel=vectorize(strlist)

file=open('tfidfmodel.sav','wb')
pickle.dump(tfidfmodel,file)
file.close()

vocab_frame=buildVocabFrame(strlist)

file=open('vocab_frame.sav','wb')
pickle.dump(vocab_frame,file)
file.close()

n=3 #number of documents required ideally in a cluster
cdict=getClusters(list(range(len(doclist))),tfidfmodel[1],n,100)

file=open('cdict.sav','wb')
pickle.dump(cdict,file)
file.close()