# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 14:18:51 2018

@author: C63165
"""

for i in range(23):
    file=open(str(i+1)+'.txt','r')
    filestr=file.read()
    file.close()
    
    file=open(str(i+1)+'.txt','w',encoding='utf')
    file.write(filestr)
    file.close()
