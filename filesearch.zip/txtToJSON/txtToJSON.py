# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 09:22:50 2018

@author: C63165
"""

import json
"""
Converting txt files to json files for importing to mongoDB
"""
ddict={}
for i in range(23):
    ddict['content']={}
    file=open(str(i+1)+'.txt','r',encoding='utf8')
    filestr=file.read().split('\n')
    file.close()
    
    ddict['content']['contents']=filestr
    
    file=open(str(i+1)+'.json','w',encoding='utf8')
    file.write(json.dumps(ddict))
    file.close()

