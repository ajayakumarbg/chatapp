import json
import re
import pprint
import pickle
import unicodedata

fe=open('dictionary.json')
f=fe.read()
fe.close()
fe = open('stopwords.txt')
f2=fe.read()
d1=f2.split()
fe.close()
print ('stopwords', len(d1))
data=json.loads(f)
result=[]
for key in data:
    key =unicodedata.normalize('NFKD', key).encode('ascii','ignore')
    # print(type(key))
    result.append(key)
print ('dict from docs', len(result))
for word in d1:
    if word not in result:
        result.append(word)

print ('all words',len(result)) 

# print(result)
string= ','.join(result)
sf=open('dictionary.txt','wb')
sf.write(string)
sf.close()
