import re


def edit_distance(str1, str2):
    str1 = ' ' + str1
    str2 = ' ' + str2
    d = {}
    x = len(str1)
    y = len(str2)

    for i in range (x):
        d[i,0] = i
    for j in range (y):
        d[0,j] = j
    for j in range(1,y):
        for i in range(1,x):
            if str1[i] == str2[j]:
                d[i, j] = d[i-1, j-1]
            else:
                d[i, j] = min(d[i-1, j], d[i, j-1], d[i-1, j-1]) + 1;
    return d[x-1, y-1]

f = open("dictionary.txt",'rb')
words = f.read()
words_list = words.split(',')


def min_edit_distance(keywords):
    
    corr_query=[]
    for query in keywords:

        query = query.lower()
        my_dict = {}
        for i in range (len(words_list)):
            result = edit_distance(query, words_list[i])
            my_dict[words_list[i]] = result
        
        corr_query.append(unicode(min(my_dict, key=my_dict.get)))

    if corr_query==keywords:
        return 1
    else:
        return corr_query

if __name__ =='__main__':
    print(result)
    
