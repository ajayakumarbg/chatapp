#!/bin/bash
python3 txtToJSON.py
DIR='/home/infinitylabs/Pictures/WikiDemo/IndexerVer7/txtToJSON/'
i=1
for file in ls "$DIR"*.json
do
    mongoimport -h ds239368.mlab.com:39368 -d vor -c testfilesearch -u amith -p amith123 --file $i.json 
    echo $i
    i=$((i+1))
done
echo  "Done exporting Documents to MongoDB"
mongoexport -h ds239368.mlab.com:39368 -d vor -c testfilesearch -u amith -p amith123 -o /home/infinitylabs/Pictures/WikiDemo/IndexerVer7/txtToJSON/filesearch.json
echo "Imported filesearch.json"
python3 ImportData.py
python3 Search.py
echo "ID.txt generated"
mongoimport -h ds239368.mlab.com:39368 -d vor -c TFIDFtest -u amith -p amith123 --file TFIDF.json
echo "exported TFIDF.json to MongoDb"
echo  "starting server"
python pymongotest.py
echo "opening browser"
firefox index.html

	
